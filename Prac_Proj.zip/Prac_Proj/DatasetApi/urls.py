from django.urls import path
from . import views
urlpatterns = [
    path('dataset', views.dataset, name="dataset"),
    path('dataset/<int:id>', views.get_dataset, name="get_dataset"),
    path('dataset/<int:id>/stats', views.dataframe_as_object, name="dataframe_as_object"),   
]
