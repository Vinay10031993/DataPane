from django.apps import AppConfig


class DatasetapiConfig(AppConfig):
    name = 'DatasetApi'
