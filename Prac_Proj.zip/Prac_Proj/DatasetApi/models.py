from django.db import models
from django.utils.timezone import now
# Create your models here.

class Datasets(models.Model):
    csv_file =  models.FileField(upload_to='media/documents',null =True,blank=True)
    filename = models.CharField(max_length=128, blank=True, null=True)
    created = models.DateTimeField(null=True, editable=False)
    updated = models.DateTimeField(auto_now=True)
    file_path = models.CharField(max_length=256, blank=True, null=True)

    @property
    def get_size(self):
        x = self.csv_file.size
        y = 512000
        if x < y:
            value = round(x/1000, 2)
            ext = ' kb'
        elif x < y*1000:
            value = round(x/1000000, 2)
            ext = ' Mb'
        else:
            value = round(x/1000000000, 2)
            ext = ' Gb'
        return str(value)+ext
